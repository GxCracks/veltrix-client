@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "JAR=VELTRIX-Launcher-0.8.0.jar"

if not exist "%JAR%" (
  echo.
  echo VELTRIX Launcher file is missing.
  echo Please download VELTRIX Client again from the official website.
  echo.
  pause
  exit /b 1
)

where javaw >nul 2>nul
if errorlevel 1 (
  echo.
  echo Java 21 was not found.
  echo Please install Java 21 and start VELTRIX again.
  echo.
  pause
  exit /b 1
)

start "VELTRIX Client" javaw -jar "%JAR%"
endlocal
