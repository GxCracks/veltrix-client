VELTRIX Client 0.8.0
====================

Start:
1. Extract this download completely.
2. Double-click START-VELTRIX.bat.
3. Java 21 is required.

This public download contains only the compiled VELTRIX launcher files needed by users.
Development source code, internal documentation, tests and build scripts are not included.

Project website:
https://gxcracks.github.io/veltrix-client/

VELTRIX is an independent project and is not affiliated with, endorsed by,
or sponsored by Mojang Studios or Microsoft.
